Nombres:    Gabriel Carmona // Jorge Ludueña
Roles:          201773509-0 //   201773507-4  

Se realizo el bonus. El servidor acepta mas de un cliente al mismo tiempo.


Como correr los programas:


Servidor:
		1.- Con una terminal colocada en la carpeta donde se encuentra el archivo "server.py" utilizar el comando "python3 server.py" en caso de estar en linux o
			py server.py si se encuentra en windows. Con esto el servidor estar iniciado y listo para recibir consultas


Cliente:
		1.- Con una terminal colocada en la carpeta donde se encuentra el archivo "cliente.py" utilizar el comando "python3 cliente.py" en caso de estar en linux o
			py cliente.py si se encuentra en windows (es necesario que el servidor este iniciado).

		2.- Una vez iniciado, igresar la url que se desee consultar, un ejemplo de esta es "www.google.com". ADVERTENCIA: Debe ser una URL correcta, en cualquier otro
			caso ocurrira un error.
